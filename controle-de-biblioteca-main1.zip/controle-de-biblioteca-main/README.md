Na listagem de livros, devem ser apresentados o 

- identificador,
- o nome,
-  o autor,
-  a data de criação
-  e o status desse livro (disponível, emprestado ou indisponível);
- 


PODER:
modificar o status (ENUM) do livro além de excluir um livro que não
está mais disponível na biblioteca na própria listagem;


TER:
 LOGIN

usuário com do tipo administrador pode registrar outros usuários

O formulário de cadastro de livros de ser validado;

MVC

dados deverão ser salvos em uma base de dado


REPO: controle-de-biblioteca


exemplo